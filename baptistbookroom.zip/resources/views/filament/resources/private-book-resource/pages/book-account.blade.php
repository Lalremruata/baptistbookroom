<x-filament-panels::page>
<div class="lg:flex">
    <div class="w-full px-3 lg:w-2/3 lg:flex-none">
        {{ $this->table }}
    </div>
</div>
<x-filament-actions::modals />
</x-filament-panels::page>