<div class=" bg-gradient-to-r from-cyan-500 to-blue-500">
    {{$this->form}}
</div>
