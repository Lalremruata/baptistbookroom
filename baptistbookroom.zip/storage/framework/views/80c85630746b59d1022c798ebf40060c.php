
<div class="flex items-center ">
    <div class="mr-4">
        <img
        src="<?php echo e(asset('/images/bcm-logo.svg')); ?>"
        alt="Baptist Bookroom"
        class="h-10"
    />
    </div>
    <div>
        <span class="text-lg font-semibold text-primary">Baptist Bookroom</span>
    </div>

</div>
<?php /**PATH /home/vagrant/code/baptistbookroom/resources/views/vendor/filament-panels/components/logo.blade.php ENDPATH**/ ?>