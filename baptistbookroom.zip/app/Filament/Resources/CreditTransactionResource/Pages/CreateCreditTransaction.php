<?php

namespace App\Filament\Resources\CreditTransactionResource\Pages;

use App\Filament\Resources\CreditTransactionResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCreditTransaction extends CreateRecord
{
    protected static string $resource = CreditTransactionResource::class;

}
