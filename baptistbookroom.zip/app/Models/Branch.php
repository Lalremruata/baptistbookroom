<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Branch extends Model
{
    use HasFactory;
    protected $fillable = [
        'branch_name'
    ];
    public function branchStock(): HasMany
    {
        return $this->HasMany(BranchStock::class);
    }
    // public function productRequests(): HasMany
    // {
    //     return $this->hasMany(ProductRequest::class);
    // }
    public function stockDistribute(): HasMany
    {
        return $this->hasMany(StockDistribute::class);
    }
    public function users(): HasMany
    {
        return $this->hasMany(User::class);
    }
    public function asset(): HasMany
    {
        return $this->hasMany(Asset::class);
    }

}
